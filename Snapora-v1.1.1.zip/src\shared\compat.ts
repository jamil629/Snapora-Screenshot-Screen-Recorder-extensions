export function isBrave(): boolean {
  return (navigator as Navigator & { brave?: unknown }).brave !== undefined;
}

export function supportsOffscreen(): boolean {
  return typeof chrome !== "undefined" && !!chrome.offscreen && !!chrome.offscreen.createDocument;
}

export function supportsTabCapture(): boolean {
  return typeof chrome !== "undefined" && !!chrome.tabCapture;
}

export function resolutionToHeight(r: "720p" | "1080p" | "4k"): number {
  return r === "720p" ? 720 : r === "4k" ? 2160 : 1080;
}

export function buildFileName(kind: "screenshot" | "recording", ext: string): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  return `snapora-${kind}-${stamp}.${ext}`;
}

export function revokeLater(url: string, ms = 30_000): void {
  window.setTimeout(() => URL.revokeObjectURL(url), ms);
}

export function cleanupStream(stream: MediaStream | null): void {
  if (!stream) return;
  for (const t of stream.getTracks()) {
    try { t.stop(); } catch { /* track already stopped */ }
  }
}
