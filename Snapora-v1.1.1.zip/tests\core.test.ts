import { sanitizeSettings, clampInt } from "../src/shared/storage.ts";
import { resolutionToHeight, buildFileName } from "../src/shared/compat.ts";
import { DEFAULT_SETTINGS } from "../src/shared/types.ts";
import { isRestrictedUrl, userMessage } from "../src/shared/errors.ts";
import test from "node:test";
import assert from "node:assert/strict";
test("sanitize clamps bad input", () => {
  const s = sanitizeSettings({ jpegQuality: 9, countdownSeconds: 99 } as never);
  assert.equal(s.jpegQuality, 1);
  assert.equal(s.countdownSeconds, 10);
});
test("defaults survive sanitize", () => {
  const s = sanitizeSettings({});
  assert.equal(s.screenshotFormat, DEFAULT_SETTINGS.screenshotFormat);
});
test("clampInt fallback", () => { assert.equal(clampInt(NaN, 0, 5, 2), 2); });
test("resolution map", () => {
  assert.equal(resolutionToHeight("720p"), 720);
  assert.equal(resolutionToHeight("4k"), 2160);
});
test("filename has stamp", () => {
  assert.match(buildFileName("screenshot", "png"), /^snapora-screenshot-\d+-/);
});
test("restricted pages blocked", () => {
  assert.equal(isRestrictedUrl("chrome://extensions"), true);
  assert.equal(isRestrictedUrl("https://chromewebstore.google.com/x"), true);
  assert.equal(isRestrictedUrl("brave://settings"), true);
  assert.equal(isRestrictedUrl("https://example.com/page"), false);
  assert.equal(isRestrictedUrl(undefined), true);
});
test("userMessage maps denial", () => {
  assert.match(userMessage(new Error("Permission denied"), "fb"), /Permission was denied/);
  assert.equal(userMessage(new Error("boom"), "fb"), "fb");
});
test("sanitize rejects bad enums", () => {
  const s = sanitizeSettings({ screenshotFormat: "gif", theme: "neon", cameraSize: 9999 } as never);
  assert.equal(s.screenshotFormat, "png");
  assert.equal(s.theme, "system");
  assert.equal(s.cameraSize, 320);
});
