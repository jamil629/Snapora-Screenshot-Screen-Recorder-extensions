import { buildFileName } from "./compat.ts";
import { downloadBlob } from "./capture.ts";

export async function exportScreenshot(blob: Blob, format: "png" | "jpg" | "pdf", jpegQuality: number): Promise<string> {
  if (blob.size === 0) throw new Error("Empty image.");
  if (format === "jpg") {
    const bmp = await createImageBitmap(blob);
    const canvas = document.createElement("canvas");
    canvas.width = bmp.width; canvas.height = bmp.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable.");
    ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bmp, 0, 0);
    const out = await new Promise<Blob | null>((r) => canvas.toBlob(r, "image/jpeg", jpegQuality));
    if (!out) throw new Error("JPEG encode failed.");
    const name = buildFileName("screenshot", "jpg");
    await downloadBlob(out, name);
    return name;
  }
  if (format === "pdf") {
    const bmp = await createImageBitmap(blob);
    const pdf = minimalPdf(bmp.width, bmp.height);
    const name = buildFileName("screenshot", "pdf");
    await downloadBlob(new Blob([pdf], { type: "application/pdf" }), name);
    return name;
  }
  const name = buildFileName("screenshot", "png");
  await downloadBlob(blob, name);
  return name;
}

export async function exportRecording(blob: Blob, asMp4: boolean): Promise<{ name: string; note: string }> {
  if (blob.size === 0) throw new Error("Empty recording.");
  if (!asMp4) {
    const name = buildFileName("recording", "webm");
    await downloadBlob(blob, name);
    return { name, note: "Saved as WebM (native, lossless container)." };
  }
  return { name: buildFileName("recording", "webm"), note: "For real MP4, use Export MP4 in the video editor (local conversion)." };
}

function minimalPdf(w: number, h: number): string {
  const pw = Math.min(595, 595);
  const ph = Math.round((pw * h) / Math.max(1, w));
  return `%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${pw} ${ph}]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF`;
}
