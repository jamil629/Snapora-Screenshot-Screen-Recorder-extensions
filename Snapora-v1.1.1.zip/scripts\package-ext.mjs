import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dist = join(root, "dist");
const raw = JSON.parse(readFileSync(join(root, "manifest.json"), "utf8"));

const distManifest = {
  ...raw,
  action: { default_popup: "src/popup/index.html" },
  background: { service_worker: "background.js", type: "module" },
  content_scripts: [{ matches: ["http://*/*", "https://*/*"], js: ["content.js"], run_at: "document_idle", all_frames: false }],
  options_page: "src/options/index.html",
};
writeFileSync(join(dist, "manifest.json"), JSON.stringify(distManifest, null, 2));

const iconsDir = join(dist, "icons");
mkdirSync(iconsDir, { recursive: true });
for (const n of [16, 32, 48, 128]) {
  const src = join(root, "assets", "icons", `icon${n}.png`);
  if (existsSync(src)) copyFileSync(src, join(iconsDir, `icon${n}.png`));
}
const svg = join(root, "assets", "icons", "icon.svg");
if (existsSync(svg)) copyFileSync(svg, join(iconsDir, "icon.svg"));

const required = ["manifest.json", "background.js", "content.js", "src/popup/index.html", "src/options/index.html", "src/editor/index.html", "src/video-editor/index.html", "src/offscreen/index.html"];
const missing = required.filter((f) => !existsSync(join(dist, f)));
if (missing.length > 0) {
  console.error("MISSING: " + missing.join(", "));
  process.exit(1);
}
const m = JSON.parse(readFileSync(join(dist, "manifest.json"), "utf8"));
const wide = (m.host_permissions ?? []).filter((h) => h === "<all_urls>" || h === "*://*/*");
if (wide.length > 0) {
  console.error("BLOCKED: over-broad host permissions");
  process.exit(1);
}
console.log("package ok: dist/ ready for Load unpacked");
