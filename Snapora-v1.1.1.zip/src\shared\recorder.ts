import { cleanupStream } from "./compat.ts";
import { logError } from "./errors.ts";
import type { RecorderResolution, RecorderSource } from "./types.ts";
import { resolutionToHeight } from "./compat.ts";

export interface RecorderOptions {
  source: RecorderSource;
  resolution: RecorderResolution;
  micOn: boolean;
  systemAudio: boolean;
  webcamOn: boolean;
}

export class RecorderEngine {
  private stream: MediaStream | null = null;
  private recorder: MediaRecorder | null = null;
  private chunks: Blob[] = [];
  private audioCtx: AudioContext | null = null;
  mimeType = "video/webm;codecs=vp9,opus";
  onData: ((size: number) => void) | null = null;

  async start(opts: RecorderOptions, streamId?: string): Promise<void> {
    this.stopTracks();
    const height = resolutionToHeight(opts.resolution);
    const display = await this.acquireDisplay(opts, height, streamId);
    const tracks: MediaStreamTrack[] = [...display.getVideoTracks()];
    if (opts.micOn) {
      const mic = await this.acquireMic().catch((e: unknown) => { logError("mic", e); return null; });
      if (mic) tracks.push(...mic.getAudioTracks());
    }
    this.stream = new MediaStream(tracks);
    const mime = pickMime();
    this.mimeType = mime;
    this.chunks = [];
    this.recorder = new MediaRecorder(this.stream, mime ? { mimeType: mime, videoBitsPerSecond: 8_000_000 } : undefined);
    this.recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) { this.chunks.push(e.data); this.onData?.(e.data.size); }
    };
    this.recorder.start(500);
  }

  pause(): void { if (this.recorder?.state === "recording") this.recorder.pause(); }
  resume(): void { if (this.recorder?.state === "paused") this.recorder.resume(); }

  async stop(): Promise<Blob> {
    const rec: MediaRecorder = this.recorder ?? (() => { throw new Error("Nothing is recording."); })();
    const done = new Promise<Blob>((resolve, reject) => {
      rec.onerror = () => reject(new Error("Recording failed."));
      rec.onstop = () => {
        const type = rec.mimeType || "video/webm";
        resolve(new Blob(this.chunks, { type }));
      };
    });
    if (rec.state !== "inactive") rec.stop();
    const blob = await done;
    this.dispose();
    if (blob.size === 0) throw new Error("Recording is empty.");
    return blob;
  }

  dispose(): void {
    this.stopTracks();
    if (this.audioCtx) { void this.audioCtx.close().catch(() => undefined); this.audioCtx = null; }
    this.recorder = null;
    this.chunks = [];
  }

  getStream(): MediaStream | null { return this.stream; }
  isActive(): boolean { return !!this.recorder && this.recorder.state !== "inactive"; }

  private stopTracks(): void { cleanupStream(this.stream); this.stream = null; }

  private async acquireDisplay(opts: RecorderOptions, height: number, streamId?: string): Promise<MediaStream> {
    if (streamId) {
      return navigator.mediaDevices.getUserMedia({
        video: { mandatory: { chromeMediaSource: "desktop", chromeMediaSourceId: streamId, maxHeight: height } } as MediaTrackConstraints,
      });
    }
    if (opts.source === "tab") {
      return navigator.mediaDevices.getDisplayMedia({ video: { height: { ideal: height } }, audio: opts.systemAudio });
    }
    return navigator.mediaDevices.getDisplayMedia({ video: { height: { ideal: height } }, audio: false });
  }

  private async acquireMic(): Promise<MediaStream | null> {
    try { return await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch { return null; }
  }
}

function pickMime(): string {
  const cands = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  for (const c of cands) { try { if (MediaRecorder.isTypeSupported(c)) return c; } catch { /* ignore */ } }
  return "";
}

export function actualResolutionLabel(stream: MediaStream | null, requested: RecorderResolution): string {
  const track = stream?.getVideoTracks()[0];
  const h = track?.getSettings().height ?? 0;
  if (!h) return `Resolution unavailable — showing requested ${requested}.`;
  const map: Record<string, number> = { "720p": 720, "1080p": 1080, "4k": 2160 };
  if ((map[requested] ?? 1080) > h + 60) return `Only ${h}p available on this display — recorded at ${h}p, not ${requested}.`;
  return `Recording at ${h}p.`;
}
