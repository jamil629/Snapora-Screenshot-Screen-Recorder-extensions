const DB = "snapora";
const STORE = "blobs";
const KEY = "lastRecording";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(new Error("IndexedDB unavailable."));
  });
}

function tx(db: IDBDatabase, mode: IDBTransactionMode): Promise<IDBObjectStore> {
  return Promise.resolve(db.transaction(STORE, mode).objectStore(STORE));
}

export async function saveRecording(blob: Blob): Promise<void> {
  if (blob.size === 0) throw new Error("Refusing to store an empty recording.");
  const db = await openDb();
  try {
    const store = await tx(db, "readwrite");
    await new Promise<void>((resolve, reject) => {
      const req = store.put(blob, KEY);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(new Error("Could not store recording (quota?)."));
    });
  } finally {
    db.close();
  }
}

export async function loadRecording(): Promise<Blob | null> {
  const db = await openDb();
  try {
    const store = await tx(db, "readonly");
    const blob = await new Promise<Blob | null>((resolve, reject) => {
      const req = store.get(KEY);
      req.onsuccess = () => resolve((req.result as Blob | undefined) ?? null);
      req.onerror = () => reject(new Error("Could not read recording."));
    });
    if (blob && !(blob instanceof Blob)) return null;
    return blob;
  } finally {
    db.close();
  }
}

export async function clearRecording(): Promise<void> {
  try {
    const db = await openDb();
    try {
      const store = await tx(db, "readwrite");
      await new Promise<void>((resolve) => {
        const req = store.delete(KEY);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
      });
    } finally {
      db.close();
    }
  } catch { /* best-effort */ }
}
