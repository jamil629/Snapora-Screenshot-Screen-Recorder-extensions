let overlay: HTMLDivElement | null = null;

chrome.runtime.onMessage.addListener((raw: unknown, _s, sendResponse) => {
  const msg = raw as { kind: string };
  if (msg.kind === "fullpage-collect") {
    void collectFullPage().then((r) => sendResponse(r));
    return true;
  }
  if (msg.kind === "page-width") {
    sendResponse({ innerWidth: window.innerWidth });
    return false;
  }
  if (msg.kind === "area-select") {
    startAreaSelect();
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

async function collectFullPage(): Promise<{ url: string; y: number; height: number }[]> {
  const prevY = window.scrollY;
  const vh = window.innerHeight;
  const total = document.documentElement.scrollHeight;
  const out: { url: string; y: number; height: number }[] = [];
  for (let y = 0; y < total; y += vh) {
    window.scrollTo(0, y);
    await wait(180);
    const url: string = await chrome.runtime.sendMessage({ kind: "capture-visible-slice" }).catch(() => "");
    if (!url) break;
    out.push({ url, y, height: Math.min(vh, total - y) });
  }
  window.scrollTo(0, prevY);
  return out;
}

function wait(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

function startAreaSelect(): void {
  cancelAreaSelect();
  const dpr = window.devicePixelRatio || 1;
  const ov = document.createElement("div");
  ov.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.35);cursor:crosshair;user-select:none;margin:0;padding:0;border:0;";
  overlay = ov;

  const box = document.createElement("div");
  box.style.cssText = "position:fixed;border:2px solid #4f8cff;background:rgba(79,140,255,.12);display:none;margin:0;padding:0;";
  ov.appendChild(box);

  const label = document.createElement("div");
  label.style.cssText = "position:fixed;display:none;background:#111;color:#fff;font:12px system-ui;padding:2px 8px;border-radius:6px;z-index:2147483647;margin:0;white-space:nowrap;";
  ov.appendChild(label);

  const bar = document.createElement("div");
  bar.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);display:none;gap:8px;align-items:center;background:#111;color:#fff;font:13px system-ui;padding:8px 12px;border-radius:10px;z-index:2147483647;";
  bar.style.display = "none";
  const hint = document.createElement("span");
  hint.textContent = "اسحب للتحديد — ثم اضبط واسحب الزوايا — ثم تأكيد";
  const okBtn = document.createElement("button");
  okBtn.textContent = "✔ تأكيد";
  okBtn.style.cssText = "padding:6px 14px;border-radius:8px;border:0;background:#22c55e;color:#fff;cursor:pointer;font:13px system-ui;";
  const noBtn = document.createElement("button");
  noBtn.textContent = "✖ إلغاء";
  noBtn.style.cssText = "padding:6px 14px;border-radius:8px;border:0;background:#555;color:#fff;cursor:pointer;font:13px system-ui;";
  const size = document.createElement("span");
  bar.append(hint, size, okBtn, noBtn);
  ov.appendChild(bar);

  let phase: "draw" | "adjust" = "draw";
  let drawing = false;
  let sx = 0, sy = 0;
  let l = 0, t = 0, w = 0, h = 0;
  let dragMode: null | "move" | string = null;
  let mx = 0, my = 0, orig = { l: 0, t: 0, w: 0, h: 0 };

  const handles: HTMLDivElement[] = [];
  const dirs = ["nw", "n", "ne", "e", "se", "s", "sw", "w"];
  const cursors: Record<string, string> = { nw: "nwse-resize", se: "nwse-resize", ne: "nesw-resize", sw: "nesw-resize", n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize" };
  for (const d of dirs) {
    const hd = document.createElement("div");
    hd.dataset.dir = d;
    hd.style.cssText = `position:fixed;width:12px;height:12px;background:#fff;border:2px solid #4f8cff;border-radius:3px;display:none;cursor:${cursors[d] ?? "default"};z-index:2147483647;margin:-7px 0 0 -7px;padding:0;`;
    hd.addEventListener("mousedown", (e) => {
      e.preventDefault(); e.stopPropagation();
      dragMode = d; mx = e.clientX; my = e.clientY;
      orig = { l, t, w, h };
    });
    ov.appendChild(hd);
    handles.push(hd);
  }

  function paint(): void {
    box.style.display = "block";
    box.style.left = l + "px"; box.style.top = t + "px";
    box.style.width = w + "px"; box.style.height = h + "px";
    label.style.display = "block";
    label.textContent = `${Math.round(w)} × ${Math.round(h)}`;
    label.style.left = l + "px";
    label.style.top = (t > 30 ? t - 26 : t + h + 6) + "px";
    size.textContent = `${Math.round(w)} × ${Math.round(h)}`;
    const pos: Record<string, [number, number]> = {
      nw: [l, t], n: [l + w / 2, t], ne: [l + w, t], e: [l + w, t + h / 2],
      se: [l + w, t + h], s: [l + w / 2, t + h], sw: [l, t + h], w: [l, t + h / 2],
    };
    for (const hd of handles) {
      const d = hd.dataset.dir ?? "";
      const p = pos[d];
      if (!p) continue;
      hd.style.display = phase === "adjust" ? "block" : "none";
      hd.style.left = p[0] + "px"; hd.style.top = p[1] + "px";
    }
  }

  function clampRect(): void {
    w = Math.max(4, Math.min(w, window.innerWidth - l));
    h = Math.max(4, Math.min(h, window.innerHeight - t));
    l = Math.max(0, Math.min(l, window.innerWidth - 4));
    t = Math.max(0, Math.min(t, window.innerHeight - 4));
  }

  ov.addEventListener("mousedown", (e) => {
    if (phase !== "draw") return;
    e.preventDefault();
    drawing = true;
    sx = e.clientX; sy = e.clientY;
    l = sx; t = sy; w = 0; h = 0;
    paint();
  });

  ov.addEventListener("mousemove", (e) => {
    if (phase === "draw" && drawing) {
      l = Math.min(sx, e.clientX); t = Math.min(sy, e.clientY);
      w = Math.abs(e.clientX - sx); h = Math.abs(e.clientY - sy);
      paint();
    }
  });

  ov.addEventListener("mouseup", (e) => {
    if (phase === "draw" && drawing) {
      drawing = false;
      l = Math.min(sx, e.clientX); t = Math.min(sy, e.clientY);
      w = Math.abs(e.clientX - sx); h = Math.abs(e.clientY - sy);
      if (w < 4 || h < 4) { box.style.display = "none"; label.style.display = "none"; return; }
      clampRect();
      phase = "adjust";
      ov.style.cursor = "default";
      bar.style.display = "flex";
      paint();
    }
  });

  box.addEventListener("mousedown", (e) => {
    if (phase !== "adjust") return;
    e.preventDefault(); e.stopPropagation();
    dragMode = "move"; mx = e.clientX; my = e.clientY;
    orig = { l, t, w, h };
  });

  document.addEventListener("mousemove", onDocMove);
  document.addEventListener("mouseup", onDocUp);

  function onDocMove(e: MouseEvent): void {
    if (!dragMode || phase !== "adjust") return;
    const dx = e.clientX - mx, dy = e.clientY - my;
    if (dragMode === "move") {
      l = orig.l + dx; t = orig.t + dy;
    } else {
      if (dragMode.includes("e")) w = orig.w + dx;
      if (dragMode.includes("s")) h = orig.h + dy;
      if (dragMode.includes("w")) { l = orig.l + dx; w = orig.w - dx; }
      if (dragMode.includes("n")) { t = orig.t + dy; h = orig.h - dy; }
      if (w < 4) { if (dragMode.includes("w")) l = orig.l + orig.w - 4; w = 4; }
      if (h < 4) { if (dragMode.includes("n")) t = orig.t + orig.h - 4; h = 4; }
    }
    clampRect();
    paint();
  }

  function onDocUp(): void { dragMode = null; }

  function onKey(e: KeyboardEvent): void {
    if (e.key === "Escape") cancelAreaSelect();
  }
  document.addEventListener("keydown", onKey);
  (ov as HTMLDivElement & { __cleanup?: () => void }).__cleanup = () => {
    document.removeEventListener("mousemove", onDocMove);
    document.removeEventListener("mouseup", onDocUp);
    document.removeEventListener("keydown", onKey);
  };

  okBtn.addEventListener("click", () => {
    const rect = { x: Math.round(l), y: Math.round(t), w: Math.round(w), h: Math.round(h), dpr };
    cancelAreaSelect();
    toast("تم التحديد — جارٍ فتح المحرر للحفظ…");
    chrome.runtime.sendMessage({ kind: "open-editor", payload: { area: rect } }).catch(() => {
      toast("تعذر فتح المحرر — حدّث الصفحة وحاول مجددًا.");
    });
  });
  noBtn.addEventListener("click", () => cancelAreaSelect());

  ov.tabIndex = 0;
  document.documentElement.appendChild(ov);
  ov.focus();
}

function cancelAreaSelect(): void {
  if (!overlay) return;
  const ov = overlay as HTMLDivElement & { __cleanup?: () => void };
  try { ov.__cleanup?.(); } catch { /* noop */ }
  overlay.remove();
  overlay = null;
}

function toast(text: string): void {
  const d = document.createElement("div");
  d.textContent = text;
  d.style.cssText = "position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#111;color:#fff;font:13px system-ui;padding:10px 16px;border-radius:10px;z-index:2147483647;margin:0;";
  document.documentElement.appendChild(d);
  window.setTimeout(() => d.remove(), 2600);
}
