import { logError } from "../shared/errors.ts";
import type { ExtensionMessage, RecordingState } from "../shared/types.ts";

let recState: RecordingState = { active: false, paused: false, startedAt: 0, source: null };

chrome.runtime.onInstalled.addListener(() => { void chrome.storage.sync.get("snapora.settings.v1"); });

chrome.commands.onCommand.addListener((command) => {
  void (async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id;
    if (tabId === undefined) return;
    if (command === "capture-visible") {
      const url = await chrome.tabs.captureVisibleTab({ format: "png" }).catch((e: unknown) => { logError("cmd-visible", e); return null; });
      if (url) await openEditor(url, null);
    } else if (command === "capture-area") {
      await chrome.tabs.sendMessage(tabId, { kind: "area-select" }).catch((e: unknown) => logError("cmd-area", e));
    } else if (command === "stop-recording") {
      await chrome.runtime.sendMessage({ kind: "stop-recording" }).catch(() => undefined);
    }
  })();
});

chrome.runtime.onMessage.addListener((raw: unknown, _sender, sendResponse) => {
  const msg = raw as ExtensionMessage;
  if (!msg || typeof msg.kind !== "string") return false;
  void handleMessage(msg).then((r) => sendResponse(r)).catch((e: unknown) => {
    logError("background", e);
    sendResponse({ ok: false, error: String(e) });
  });
  return true;
});

async function handleMessage(msg: ExtensionMessage): Promise<unknown> {
  switch (msg.kind) {
    case "capture-visible": {
      const url = await chrome.tabs.captureVisibleTab({ format: "png" });
      await openEditor(url, null);
      return { ok: true };
    }
    case "capture-visible-slice": {
      const url = await chrome.tabs.captureVisibleTab({ format: "png" });
      return url;
    }
    case "open-editor":
      await openEditorFromPayload(msg.payload);
      return { ok: true };
    case "open-video-editor":
      await chrome.tabs.create({ url: chrome.runtime.getURL("src/video-editor/index.html") });
      return { ok: true };
    case "start-recording": {
      recState = { active: true, paused: false, startedAt: Date.now(), source: (msg.payload?.source as RecordingState["source"]) ?? "tab" };
      await ensureOffscreen();
      await chrome.runtime.sendMessage({ kind: "start-recording", payload: msg.payload }).catch(() => undefined);
      return { ok: true };
    }
    case "stop-recording":
    case "pause-recording":
    case "resume-recording":
      await chrome.runtime.sendMessage(msg).catch(() => undefined);
      if (msg.kind === "stop-recording") recState = { active: false, paused: false, startedAt: 0, source: null };
      if (msg.kind === "pause-recording") recState = { ...recState, paused: true };
      if (msg.kind === "resume-recording") recState = { ...recState, paused: false };
      return { ok: true };
    case "recording-state":
      return { ok: true, state: recState };
    default:
      return { ok: false, error: "unknown-kind" };
  }
}

async function openEditorFromPayload(payload: Record<string, unknown> | undefined): Promise<void> {
  const direct = typeof payload?.url === "string" ? payload.url : "";
  const area = payload?.area as { x: number; y: number; w: number; h: number; dpr: number } | undefined;
  if (direct) {
    await openEditor(direct, null);
    return;
  }
  if (area && area.w >= 4 && area.h >= 4) {
    const url = await chrome.tabs.captureVisibleTab({ format: "png" });
    await openEditor(url, area);
    return;
  }
  throw new Error("Nothing to edit.");
}

async function openEditor(dataUrl: string, area: { x: number; y: number; w: number; h: number; dpr: number } | null): Promise<void> {
  if (!dataUrl) throw new Error("Empty capture.");
  await chrome.storage.local.set({ "snapora.lastShot": { url: dataUrl, area, at: Date.now() } });
  await chrome.tabs.create({ url: chrome.runtime.getURL("src/editor/index.html") });
}

async function ensureOffscreen(): Promise<void> {
  try {
    if (chrome.offscreen && chrome.offscreen.hasDocument && await chrome.offscreen.hasDocument()) return;
    await chrome.offscreen.createDocument({
      url: chrome.runtime.getURL("src/offscreen/index.html"),
      reasons: [chrome.offscreen.Reason.USER_MEDIA],
      justification: "Record display/tab media with MediaRecorder offscreen.",
    });
  } catch (e) {
    logError("offscreen", e);
  }
}
