import { resolve } from "node:path";
import { defineConfig } from "vite";

export default defineConfig({
  build: {
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: false,
    rollupOptions: {
      input: {
        popup: resolve(__dirname, "src/popup/index.html"),
        options: resolve(__dirname, "src/options/index.html"),
        editor: resolve(__dirname, "src/editor/index.html"),
        "video-editor": resolve(__dirname, "src/video-editor/index.html"),
        offscreen: resolve(__dirname, "src/offscreen/index.html"),
        background: resolve(__dirname, "src/background/service-worker.ts"),
        content: resolve(__dirname, "src/content/content.ts"),
      },
      output: {
        entryFileNames: (info) => {
          if (info.name === "background") return "background.js";
          if (info.name === "content") return "content.js";
          return "assets/[name]-[hash].js";
        },
      },
    },
  },
  publicDir: "assets",
});
