import { loadSettings, saveSettings } from "../shared/storage.ts";

const id = (x: string) => document.getElementById(x) as HTMLInputElement & HTMLSelectElement;

async function init(): Promise<void> {
  const s = await loadSettings();
  id("fmt").value = s.screenshotFormat;
  id("q").value = String(s.jpegQuality);
  id("res").value = s.recorderResolution;
  id("cd").value = String(s.countdownSeconds);
  (id("mic") as HTMLInputElement).checked = s.micDefault;
  (id("sys") as HTMLInputElement).checked = s.systemAudioDefault;
  (id("cam") as HTMLInputElement).checked = s.webcamDefault;
  id("th").value = s.theme;
  id("save").onclick = async () => {
    await saveSettings({
      ...s,
      screenshotFormat: (id("fmt").value === "jpg" || id("fmt").value === "pdf" ? id("fmt").value : "png") as typeof s.screenshotFormat,
      jpegQuality: Number(id("q").value) || 0.92,
      recorderResolution: (id("res").value === "720p" || id("res").value === "4k" ? id("res").value : "1080p") as typeof s.recorderResolution,
      countdownSeconds: Math.min(10, Math.max(0, Number(id("cd").value) || 0)),
      micDefault: (id("mic") as unknown as HTMLInputElement).checked,
      systemAudioDefault: (id("sys") as unknown as HTMLInputElement).checked,
      webcamDefault: (id("cam") as unknown as HTMLInputElement).checked,
      theme: (id("th").value === "dark" || id("th").value === "light" ? id("th").value : "system") as typeof s.theme,
    });
    (document.getElementById("st") as HTMLElement).textContent = "Saved.";
  };
}
void init();
