export interface Mp4Progress {
  fraction: number;
  bytes: number;
}

export interface Mp4Handle {
  promise: Promise<Blob>;
  cancel: () => Promise<void>;
}

export function convertWebmToMp4(source: Blob, onProgress: (p: Mp4Progress) => void): Mp4Handle {
  let cancelFn: (() => Promise<void>) | null = null;
  const promise = (async (): Promise<Blob> => {
    if (source.size === 0) throw new Error("Recording is empty — nothing to convert.");
    if (typeof VideoEncoder === "undefined") throw new Error("This browser has no WebCodecs encoder.");
    const { Input, Output, Mp4OutputFormat, BufferTarget, BlobSource, Conversion, ALL_FORMATS } = await import("mediabunny");
    const input = new Input({ source: new BlobSource(source), formats: ALL_FORMATS });
    const output = new Output({ format: new Mp4OutputFormat(), target: new BufferTarget() });
    const conversion = await Conversion.init({ input, output });
    if (!conversion.isValid) {
      const reasons = conversion.discardedTracks.map((t) => `${t.track.type}:${t.reason}`).join(", ");
      throw new Error(
        reasons.includes("no_encodable_target_codec")
          ? "This browser cannot encode MP4 (no H.264 encoder). Your WebM file is untouched."
          : `Cannot convert to MP4 (${reasons || "invalid conversion"}). Your WebM file is untouched.`,
      );
    }
    conversion.onProgress = (v: number) => {
      onProgress({ fraction: Math.min(1, Math.max(0, v)), bytes: 0 });
    };
    const stopBytes = output.target.on("write", ({ end }: { start: number; end: number }) => {
      onProgress({ fraction: -1, bytes: end });
    });
    try {
      cancelFn = () => conversion.cancel();
      await conversion.execute();
    } finally {
      cancelFn = null;
      stopBytes();
    }
    const buf = output.target.buffer;
    if (!buf || buf.byteLength === 0) throw new Error("MP4 output is empty.");
    return new Blob([buf as BlobPart], { type: "video/mp4" });
  })();
  return {
    promise,
    cancel: async () => { if (cancelFn) await cancelFn(); },
  };
}
