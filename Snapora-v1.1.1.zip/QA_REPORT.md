# QA_REPORT — Snapora v1.0.1 Acceptance Audit (2026-09-29)

Auditors: Chromium Extension Engineer + QA + Security + Performance + UX. Method: file-by-file,
feature-by-feature, runtime-by-runtime. Loop per defect: Detect → Diagnose → Fix → Build → Test → Regression → Recheck.

## Verdicts legend

- **FIXED** — found, root-caused, patched, rebuilt, re-tested green.
- **PASS** — verified by an actually-executed check (typecheck / test / build / static script).
- **LIMITATION** — blocked by Chromium/OS constraints, handled with honest UI, not faked.
- **NOT VERIFIED** — cannot be proven without a live browser; listed explicitly, never claimed.

## FIXED (9 defects, all re-tested)

| # | Severity | Location | Root cause | Fix | Re-test |
|---|----------|----------|-----------|-----|---------|
| 1 | critical | `src/background/service-worker.ts` | No handler for `capture-visible-slice` → every full-page slice returned `unknown-kind`, full-page capture silently produced nothing | Added `capture-visible-slice` handler returning `captureVisibleTab` data URL; added `MessageKind` | typecheck + build green |
| 2 | critical | area-capture flow | Content script sent `{area}` rect but background discarded payload and editor never cropped — area capture opened a blank editor | Background now captures visible tab + stores `{url, area}`; editor crops with DPR math and clamps out-of-range rects | typecheck + build green |
| 3 | critical | `src/offscreen/offscreen.ts` | `stop()` converted blob to `arrayBuffer` then dropped it — recordings were never saved anywhere | Stop now downloads native WebM via `chrome.downloads` from an object URL (revoked after 120s), stores metadata + error state | typecheck + build green |
| 4 | high | `src/shared/recorder.ts` | `acquireTabAudio()` called `getDisplayMedia` a second time → double permission prompt for tab+system-audio | Removed; audio requested once via `acquireDisplay` (`audio: opts.systemAudio`) | tests 8/8 |
| 5 | high | `src/popup/popup.ts` | Cancelling the desktop picker still disabled Start and fired `start-recording` with no source → stuck recording state | Early return with "Recording cancelled" message when `streamId` empty | typecheck green |
| 6 | high | editor tools | Requested tools (circle/line/highlighter/eraser/resize/rotate) had no implementation path; shipping buttons for them would be fake UI | Implemented all six for real (ellipse, line, alpha highlighter, destination-out eraser, aspect resize ≤8000px, 90° rotate) | build green |
| 7 | medium | `assets/icons/` | PNGs were SVG text copies — invalid PNGs, store rejection risk | New `scripts/gen-icons.mjs` writes valid PNGs (magic `89 50 4E 47` verified for 16/32/48/128) | byte-checked |
| 8 | medium | `manifest.json` | `alarms` permission requested but never used | Removed; 7 permissions remain, each mapped in README | qa-check green |
| 9 | medium | `src/content/content.ts` | Dead `querySelectorAll("*").forEach(noop)` — full-document traversal per capture for nothing | Deleted | build green |

Also fixed during the loop: `qa-check.mjs` Windows path bug, `MessageKind` gap, `ImageCapture.grabFrame` lib typing, orphaned copy-handler brace, `package-ext.mjs` unused import.

## PASS (executed)

- `tsc --noEmit` strict: green, 0 errors.
- Unit tests `tests/core.test.ts`: 8/8 green (sanitize, clamp, resolution, filename, restricted URLs ×5, userMessage, enum rejection).
- `vite build`: 24 modules, 0 warnings-as-errors.
- `scripts/package-ext.mjs`: all 8 required dist files present, no broad hosts.
- `scripts/qa-check.mjs`: no innerHTML/eval/new Function/CDN/remote script/TODO-mock-placeholder in src; permissions least-privilege; manifest structure ok.

## Test matrix (static + unit level)

| Feature | Success | Failure/cancel/denied | Result |
|---------|---------|----------------------|--------|
| Capture visible | code path verified | restricted-page guard unit-tested (chrome://, store, brave://, undefined) | PASS (logic) |
| Full page | slice handler added, stitching guards empty blob | empty-slice break + restore scroll | PASS (logic) |
| Area select | rect → crop with DPR + clamp | w/h<4 rejected, cancel = Escape | PASS (logic) |
| Screen/window shot | ImageCapture frame → dataURL → editor, tracks stopped in `finally` | picker cancel throws honest error | PASS (logic) |
| Recording start/stop/pause/resume | engine + offscreen download + error state | start-fail/empty-blob/download-fail all logged to storage + surfaced | PASS (logic) |
| Editor tools (12) | all implemented, undo/redo ≤30 steps | canvas-oversize guarded with try/catch | PASS (logic) |
| PNG/JPG/PDF export | converters reject empty blob | JPEG fallback fill, PDF minimal writer | PASS (logic) |
| Clipboard copy/paste | try/catch with user message | failure surfaced, logged | PASS (logic) |
| Security static | no XSS sinks, no remote code, no secrets, no network calls at all in src | — | PASS |
| Performance static | no new deps (only TS/vite dev), no polling, streams/tracks/URLs/AudioContext all have cleanup paths | — | PASS |

## LIMITATION (honest, by design)

- System audio availability depends on OS/browser/source — recording continues without it; UI says so.
- 4K records at the display's real height; UI reports actual height, never claims fake 4K.
- MP4: no fake `.mp4` file is ever produced; native WebM is saved with an explicit note.
- `chrome://`, Web Store, and browser internals cannot be captured (Chromium restriction) — popup shows a message instead of crashing.
- Webcam overlay PiP and FFmpeg remux intentionally not bundled (RAM/complexity) — documented in README.

## NOT VERIFIED (needs a live browser — not claimed as working)

- Real end-to-end capture/recording on Chrome + Brave, long recordings, multi-monitor, high-DPI, RTL/Arabic pages, iframes, lazy-load/sticky full-pages, mic/webcam absent, tab close mid-record, storage-full, clipboard/download OS failures, memory growth over repeated captures.
- To verify: load `dist/` unpacked, run the matrix above manually, watch `chrome://extensions` Errors and the service-worker console.

## Files changed

`src/background/service-worker.ts`, `src/content/content.ts`, `src/shared/types.ts`, `src/shared/recorder.ts`,
`src/offscreen/offscreen.ts`, `src/editor/index.html`, `src/editor/editor.ts`, `src/popup/index.html`,
`src/popup/popup.ts`, `src/video-editor/index.html`, `src/video-editor/video-editor.ts`, `manifest.json`, `assets/icons/icon{16,32,48,128}.png`,
`scripts/gen-icons.mjs`, `scripts/qa-check.mjs`, `scripts/package-ext.mjs`, `tests/core.test.ts`,
`README.md`, `CHANGELOG.md`, `QA_REPORT.md`.

## Addendum v1.1.0 — real MP4 export (FIXED as a feature delivery, same loop)

- Decision (researched, not guessed): FFmpeg.wasm rejected — ~30 MB, GPL/LGPL weight, slow software encode,
  worker/CSP friction in MV3. Chosen: **mediabunny** (MPL-2.0, zero deps, tree-shakeable, WebCodecs hardware
  encode), verified against official docs (Conversion API, `onProgress` 0–1, `cancel()`, `isValid`/`discardedTracks`).
- New: `src/shared/mp4.ts` (lazy `import("mediabunny")`, honest errors for empty input / missing WebCodecs /
  `no_encodable_target_codec`), `src/shared/blob-store.ts` (IndexedDB recording persistence),
  video-editor Export MP4 + Cancel + `<progress>` + MB-written indicator, offscreen persists blob on stop,
  editor preview now plays the actual recording.
- Measured: mediabunny ships as a separate lazy chunk (585 KB / 148 KB gzip) loaded only on Export MP4 click;
  popup/editor/offscreen chunks unchanged in size class.
- Regression: typecheck 0 errors, 8/8 tests, build 97 modules, `package-ext` + `qa-check` green.
- NOT VERIFIED: end-to-end MP4 conversion in a live browser (needs H.264 encoder); failure path is designed to
  fail loudly with the WebM untouched.
