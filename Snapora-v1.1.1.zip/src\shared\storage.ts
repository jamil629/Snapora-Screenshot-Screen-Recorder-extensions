import { DEFAULT_SETTINGS, type SnaporaSettings } from "./types.ts";

const KEY = "snapora.settings.v1";
const DRAFT_KEY = "snapora.draft.v1";

export async function loadSettings(): Promise<SnaporaSettings> {
  try {
    const got = await chrome.storage.sync.get(KEY);
    const raw = got[KEY] as Partial<SnaporaSettings> | undefined;
    if (!raw) return { ...DEFAULT_SETTINGS };
    return sanitizeSettings(raw);
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(next: SnaporaSettings): Promise<void> {
  await chrome.storage.sync.set({ [KEY]: sanitizeSettings(next) });
}

export function sanitizeSettings(raw: Partial<SnaporaSettings>): SnaporaSettings {
  const q = Number(raw.jpegQuality);
  return {
    screenshotFormat: raw.screenshotFormat === "jpg" || raw.screenshotFormat === "pdf" ? raw.screenshotFormat : "png",
    jpegQuality: Number.isFinite(q) ? Math.min(1, Math.max(0.5, q)) : 0.92,
    recorderResolution: raw.recorderResolution === "720p" || raw.recorderResolution === "4k" ? raw.recorderResolution : "1080p",
    countdownSeconds: clampInt(Number(raw.countdownSeconds), 0, 10, 3),
    micDefault: raw.micDefault === true,
    systemAudioDefault: raw.systemAudioDefault !== false,
    webcamDefault: raw.webcamDefault === true,
    cameraPosition: ["br", "bl", "tr", "tl"].includes(String(raw.cameraPosition)) ? (raw.cameraPosition as SnaporaSettings["cameraPosition"]) : "br",
    cameraSize: clampInt(Number(raw.cameraSize), 96, 320, 160),
    saveFolder: typeof raw.saveFolder === "string" ? raw.saveFolder.slice(0, 256) : "",
    theme: raw.theme === "dark" || raw.theme === "light" ? raw.theme : "system",
    privacyStrict: raw.privacyStrict !== false,
  };
}

export function clampInt(v: number, min: number, max: number, fallback: number): number {
  if (!Number.isFinite(v)) return fallback;
  return Math.min(max, Math.max(min, Math.round(v)));
}

export async function saveDraft(draft: Record<string, unknown>): Promise<void> {
  try {
    await chrome.storage.local.set({ [DRAFT_KEY]: { ...draft, savedAt: Date.now() } });
  } catch { /* storage full or unavailable: draft is best-effort */ }
}

export async function loadDraft<T extends Record<string, unknown>>(): Promise<(T & { savedAt: number }) | null> {
  try {
    const got = await chrome.storage.local.get(DRAFT_KEY);
    const d = got[DRAFT_KEY] as (T & { savedAt: number }) | undefined;
    return d ?? null;
  } catch {
    return null;
  }
}

export async function clearDraft(): Promise<void> {
  try { await chrome.storage.local.remove(DRAFT_KEY); } catch { /* noop */ }
}
