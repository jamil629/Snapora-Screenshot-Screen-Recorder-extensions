import { createDeflate } from "node:zlib";
import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const dir = join(dirname(fileURLToPath(import.meta.url)), "..", "assets", "icons");

function crc32(buf) {
  let table = crc32.t;
  if (!table) {
    table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
    crc32.t = table;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.from(type, "ascii");
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([td, data])));
  return Buffer.concat([len, td, data, crc]);
}

function render(size) {
  const px = Buffer.alloc(size * size * 4);
  const cx = size / 2;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const edge = Math.min(x, y, size - 1 - x, size - 1 - y);
      if (edge < size * 0.02) continue;
      const dx = x - cx, dy = y - cx;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const ring = size * 0.22;
      const inRing = Math.abs(dist - ring) < size * 0.055;
      const bar = y > size * 0.78 && y < size * 0.88 && Math.abs(x - cx) < size * 0.16;
      const t = y / size;
      px[i] = Math.round(30 + 40 * t);
      px[i + 1] = Math.round(60 + 60 * t);
      px[i + 2] = Math.round(140 + 80 * t);
      px[i + 3] = 255;
      if (inRing || bar) {
        px[i] = 96; px[i + 1] = 150; px[i + 2] = 255; px[i + 3] = 255;
      }
    }
  }
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    px.copy(raw, y * (size * 4 + 1) + 1, y * size * 4, (y + 1) * size * 4);
  }
  return raw;
}

async function main() {
  for (const size of [16, 32, 48, 128]) {
    const deflated = await new Promise((res, rej) => {
      const parts = [];
      const d = createDeflate({ level: 9 });
      d.on("data", (c) => parts.push(c));
      d.on("end", () => res(Buffer.concat(parts)));
      d.on("error", rej);
      d.end(render(size));
    });
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4);
    ihdr[8] = 8; ihdr[9] = 6;
    const png = Buffer.concat([
      Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
      chunk("IHDR", ihdr),
      chunk("IDAT", deflated),
      chunk("IEND", Buffer.alloc(0)),
    ]);
    writeFileSync(join(dir, `icon${size}.png`), png);
    console.log(`icon${size}.png: ${png.length} bytes`);
  }
}

void main();
