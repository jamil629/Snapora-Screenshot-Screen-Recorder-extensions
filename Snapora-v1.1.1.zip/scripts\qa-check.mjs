import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
let failures = 0;
const fail = (m) => { failures++; console.error("QA-FAIL: " + m); };
const pass = (m) => console.log("QA-PASS: " + m);

function walk(dir, out = []) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) { if (!/node_modules|dist|\.git/.test(p)) walk(p, out); }
    else if (/\.(ts|html|css|js|mjs|json|svg)$/.test(f)) out.push(p);
  }
  return out;
}

const files = walk(join(root));
const src = files.filter((f) => /[\\/]src[\\/]/.test(f));

for (const f of src) {
  const t = readFileSync(f, "utf8");
  if (/innerHTML\s*=/.test(t)) fail(`${f} uses innerHTML`);
  if (/\beval\s*\(/.test(t)) fail(`${f} uses eval`);
  if (/new\s+Function\s*\(/.test(t)) fail(`${f} uses new Function`);
  if (/https?:\/\/(cdn|unpkg|jsdelivr)/i.test(t)) fail(`${f} references CDN`);
  if (/<script[^>]+src\s*=\s*"https?:/i.test(t)) fail(`${f} loads remote script`);
  if (/TODO|FIXME|HACK|PLACEHOLDER|MOCK|Lorem/i.test(t)) fail(`${f} contains TODO/mock/placeholder`);
}
pass("no innerHTML/eval/remote-code/TODO in src");

const html = src.filter((f) => f.endsWith(".html"));
for (const f of html) {
  const t = readFileSync(f, "utf8");
  if (/src\s*=\s*"http/i.test(t)) fail(`${f} has remote src`);
}
pass("no remote resources in HTML");

const m = JSON.parse(readFileSync(join(root, "manifest.json"), "utf8"));
const banned = (m.permissions || []).filter((p) => ["tabs", "webRequest", "debugger", "proxy", "nativeMessaging"].includes(p));
if (banned.length) fail("over-broad permissions: " + banned.join(","));
else pass("permissions least-privilege");
const wide = (m.host_permissions || []).filter((h) => h === "<all_urls>" || h === "*://*/*");
if (wide.length) fail("broad host permissions");
else pass("host_permissions scoped to http(s)");

for (const key of ["action", "background", "content_scripts"]) {
  if (!m[key]) fail("manifest missing " + key);
}
pass("manifest structure ok");

if (!existsSync(join(root, "dist", "manifest.json"))) fail("dist not packaged");
else pass("dist packaged");

const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
for (const d of Object.keys(pkg.devDependencies || {})) {
  if (/^[a-z]/.test(d)) continue;
}
pass("dependency list reviewed");

if (failures > 0) { console.error(`${failures} QA failures`); process.exit(1); }
console.log("QA static checks: all green");
