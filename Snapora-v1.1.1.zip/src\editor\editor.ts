import { captureFullPage } from "../shared/capture.ts";
import { logError } from "../shared/errors.ts";
import { exportScreenshot } from "../shared/exporter.ts";
import { loadSettings } from "../shared/storage.ts";

const cv = document.getElementById("cv") as HTMLCanvasElement;
const ctx = cv.getContext("2d") as CanvasRenderingContext2D;
const history: ImageData[] = [];
const future: ImageData[] = [];
let tool = "pen";
let drawing = false;
let sx = 0, sy = 0;

function push(): void {
  try {
    history.push(ctx.getImageData(0, 0, cv.width, cv.height));
    if (history.length > 30) history.shift();
    future.length = 0;
  } catch { /* canvas too large */ }
}

function pos(e: MouseEvent): [number, number] {
  const r = cv.getBoundingClientRect();
  return [(e.clientX - r.left) * (cv.width / r.width), (e.clientY - r.top) * (cv.height / r.height)];
}
function color(): string { return (document.getElementById("color") as HTMLInputElement).value; }
function width(): number { return Number((document.getElementById("size") as HTMLInputElement).value) || 3; }

document.querySelectorAll("[data-tool]").forEach((b) => (b as HTMLButtonElement).onclick = () => { tool = (b as HTMLElement).dataset.tool ?? "pen"; });
cv.onmousedown = (e) => { drawing = true; [sx, sy] = pos(e); push(); if (tool === "blur") applyBlur(sx, sy, 60); };
cv.onmousemove = (e) => {
  if (!drawing) return;
  const [x, y] = pos(e);
  if (tool === "eraser") {
    ctx.save();
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath(); ctx.arc(x, y, 4 + width() * 2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    return;
  }
  ctx.save();
  ctx.globalAlpha = tool === "highlighter" ? 0.35 : 1;
  ctx.strokeStyle = color(); ctx.lineWidth = tool === "highlighter" ? width() * 4 : width(); ctx.lineCap = "round";
  if (tool === "pen" || tool === "highlighter") { ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(x, y); ctx.stroke(); sx = x; sy = y; }
  ctx.restore();
};
cv.onmouseup = (e) => {
  if (!drawing) return;
  drawing = false;
  const [x, y] = pos(e);
  ctx.strokeStyle = color(); ctx.fillStyle = color(); ctx.lineWidth = width();
  if (tool === "rect") ctx.strokeRect(sx, sy, x - sx, y - sy);
  else if (tool === "circle") { ctx.beginPath(); ctx.ellipse((sx + x) / 2, (sy + y) / 2, Math.abs(x - sx) / 2, Math.abs(y - sy) / 2, 0, 0, Math.PI * 2); ctx.stroke(); }
  else if (tool === "line") { ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(x, y); ctx.stroke(); }
  else if (tool === "arrow") drawArrow(sx, sy, x, y);
  else if (tool === "text") { const t = prompt("Text:"); if (t) { ctx.font = `${16 + width() * 2}px system-ui`; ctx.fillText(t, x, y); } }
  else if (tool === "blur") applyBlur(Math.min(sx, x), Math.min(sy, y), Math.max(Math.abs(x - sx), 20));
};

function drawArrow(x1: number, y1: number, x2: number, y2: number): void {
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  const a = Math.atan2(y2 - y1, x2 - x1);
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - 12 * Math.cos(a - 0.4), y2 - 12 * Math.sin(a - 0.4));
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - 12 * Math.cos(a + 0.4), y2 - 12 * Math.sin(a + 0.4));
  ctx.stroke();
}

function applyBlur(x: number, y: number, s: number): void {
  try {
    const d = ctx.getImageData(Math.max(0, x), Math.max(0, y), Math.min(s, 300), Math.min(s, 300));
    const px = 6;
    for (let yy = 0; yy < d.height; yy += px) for (let xx = 0; xx < d.width; xx += px) {
      const i = (yy * d.width + xx) * 4;
      for (let oy = 0; oy < px && yy + oy < d.height; oy++) for (let ox = 0; ox < px && xx + ox < d.width; ox++) {
        const j = ((yy + oy) * d.width + xx + ox) * 4;
        d.data[j] = d.data[i] as number; d.data[j + 1] = d.data[i + 1] as number; d.data[j + 2] = d.data[i + 2] as number;
      }
    }
    ctx.putImageData(d, Math.max(0, x), Math.max(0, y));
  } catch { /* ignore */ }
}

(document.getElementById("undo") as HTMLButtonElement).onclick = () => {
  const prev = history.pop();
  if (!prev) return;
  try { future.push(ctx.getImageData(0, 0, cv.width, cv.height)); ctx.putImageData(prev, 0, 0); } catch { /*noop*/ }
};
(document.getElementById("redo") as HTMLButtonElement).onclick = () => {
  const n = future.pop();
  if (!n) return;
  try { history.push(ctx.getImageData(0, 0, cv.width, cv.height)); ctx.putImageData(n, 0, 0); } catch { /*noop*/ }
};
(document.getElementById("crop") as HTMLButtonElement).onclick = () => {
  push();
  const w = Math.round(cv.width * 0.9), h = Math.round(cv.height * 0.9);
  const d = ctx.getImageData(0, 0, w, h);
  cv.width = w; cv.height = h; ctx.putImageData(d, 0, 0);
};
(document.getElementById("resize") as HTMLButtonElement).onclick = () => {
  const raw = prompt(`New width in px (current ${cv.width}, keeps aspect):`);
  if (!raw) return;
  const w = Math.min(8000, Math.max(16, Math.round(Number(raw))));
  if (!Number.isFinite(w)) return;
  push();
  const h = Math.round((cv.height * w) / Math.max(1, cv.width));
  const tmp = document.createElement("canvas");
  tmp.width = cv.width; tmp.height = cv.height;
  tmp.getContext("2d")?.drawImage(cv, 0, 0);
  cv.width = w; cv.height = h;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(tmp, 0, 0, w, h);
};
(document.getElementById("rotate") as HTMLButtonElement).onclick = () => {
  push();
  const tmp = document.createElement("canvas");
  tmp.width = cv.width; tmp.height = cv.height;
  tmp.getContext("2d")?.drawImage(cv, 0, 0);
  cv.width = tmp.height; cv.height = tmp.width;
  ctx.save();
  ctx.translate(cv.width / 2, cv.height / 2);
  ctx.rotate(Math.PI / 2);
  ctx.drawImage(tmp, -tmp.width / 2, -tmp.height / 2);
  ctx.restore();
};
(document.getElementById("copy") as HTMLButtonElement).onclick = async () => {
  try {
    const blob = await new Promise<Blob | null>((r) => cv.toBlob(r, "image/png"));
    if (blob) await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
    (document.getElementById("st") as HTMLElement).textContent = "Copied.";
  } catch (e) { (document.getElementById("st") as HTMLElement).textContent = "Copy failed."; logError("copy", e); }
};
(document.getElementById("paste") as HTMLButtonElement).onclick = async () => {
  try {
    const items = await navigator.clipboard.read();
    for (const it of items) {
      const t = it.types.find((x) => x.startsWith("image/"));
      if (!t) continue;
      const blob = await it.getType(t);
      const bmp = await createImageBitmap(blob);
      cv.width = bmp.width; cv.height = bmp.height; ctx.drawImage(bmp, 0, 0);
      push();
    }
  } catch (e) { logError("paste", e); }
};
(document.getElementById("save") as HTMLButtonElement).onclick = async () => {
  try {
    const s = await loadSettings();
    const fmt = ((document.getElementById("fmt") as HTMLSelectElement).value === "jpg" || (document.getElementById("fmt") as HTMLSelectElement).value === "pdf") ? (document.getElementById("fmt") as HTMLSelectElement).value as "jpg" | "pdf" : s.screenshotFormat;
    const blob = await new Promise<Blob | null>((r) => cv.toBlob(r, "image/png"));
    if (!blob) throw new Error("Encode failed.");
    const name = await exportScreenshot(blob, fmt === "png" ? s.screenshotFormat : fmt, s.jpegQuality);
    (document.getElementById("st") as HTMLElement).textContent = "Saved " + name;
  } catch (e) { (document.getElementById("st") as HTMLElement).textContent = e instanceof Error ? e.message : "Save failed."; logError("save", e); }
};

async function boot(): Promise<void> {
  try {
    const q = new URLSearchParams(location.search);
    const fullId = Number(q.get("fullpage"));
    if (Number.isFinite(fullId) && fullId > 0) {
      const blob = await captureFullPage(fullId);
      const bmp = await createImageBitmap(blob);
      cv.width = bmp.width; cv.height = bmp.height; ctx.drawImage(bmp, 0, 0);
      return;
    }
    const got = await chrome.storage.local.get("snapora.lastShot");
    const shot = got["snapora.lastShot"] as { url: string; area: { x: number; y: number; w: number; h: number; dpr: number } | null } | undefined;
    if (shot?.url) {
      const img = new Image();
      img.onload = () => {
        const a = shot.area;
        if (a && a.w >= 4 && a.h >= 4) {
          const sx = Math.round(a.x * a.dpr), sy = Math.round(a.y * a.dpr);
          const sw = Math.min(Math.round(a.w * a.dpr), img.naturalWidth - sx);
          const sh = Math.min(Math.round(a.h * a.dpr), img.naturalHeight - sy);
          if (sw > 0 && sh > 0) {
            cv.width = sw; cv.height = sh;
            ctx.drawImage(img, Math.max(0, sx), Math.max(0, sy), sw, sh, 0, 0, sw, sh);
            return;
          }
        }
        cv.width = img.naturalWidth; cv.height = img.naturalHeight; ctx.drawImage(img, 0, 0);
      };
      img.src = shot.url;
    } else {
      cv.width = 900; cv.height = 500;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, 900, 500);
      ctx.fillStyle = "#333"; ctx.font = "20px system-ui";
      ctx.fillText("Paste an image or capture a screenshot to begin.", 40, 60);
    }
  } catch (e) {
    (document.getElementById("st") as HTMLElement).textContent = e instanceof Error ? e.message : "Capture failed.";
    logError("editor-boot", e);
  }
}
void boot();
