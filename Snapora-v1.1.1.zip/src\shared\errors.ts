const LOG_KEY = "snapora.errors.v1";
const MAX_ENTRIES = 50;

export interface ErrorEntry {
  at: number;
  context: string;
  message: string;
}

export function logError(context: string, err: unknown): void {
  const message = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
  void chrome.storage.local.get(LOG_KEY).then((got) => {
    const list = (got[LOG_KEY] as ErrorEntry[] | undefined) ?? [];
    list.push({ at: Date.now(), context: context.slice(0, 120), message: message.slice(0, 500) });
    void chrome.storage.local.set({ [LOG_KEY]: list.slice(-MAX_ENTRIES) });
  }).catch(() => undefined);
}

export function userMessage(err: unknown, fallback: string): string {
  if (err instanceof Error) {
    if (/permission|denied|NotAllowed/i.test(err.message)) return "Permission was denied. Allow access and try again.";
    if (/No active|No tab|Cannot access/i.test(err.message)) return "This page cannot be captured. Try a regular web page.";
    return fallback;
  }
  return fallback;
}

export function isRestrictedUrl(url: string | undefined): boolean {
  if (!url) return true;
  return /^(chrome|chrome-extension|brave|edge|about|view-source|chrome-search|chrome-native):\/\//.test(url)
    || /^https:\/\/chrome\.google\.com\/webstore/.test(url)
    || /^https:\/\/chromewebstore\.google\.com/.test(url);
}
