import { isRestrictedUrl, logError, userMessage } from "./errors.ts";

export async function activeTab(): Promise<chrome.tabs.Tab> {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab?.id) throw new Error("No active tab");
  return tab;
}

export async function captureVisible(): Promise<string> {
  const tab = await activeTab();
  if (isRestrictedUrl(tab.url)) throw new Error("restricted-page");
  try {
    return await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  } catch (e) {
    logError("captureVisible", e);
    throw new Error(userMessage(e, "Could not capture this tab."));
  }
}

export interface FullPageSlice { url: string; y: number; height: number; }

export async function captureFullPage(tabId: number): Promise<Blob> {
  const slices = await chrome.tabs.sendMessage<unknown, FullPageSlice[]>(tabId, { kind: "fullpage-collect" })
    .catch((e: unknown) => { logError("fullpage-collect", e); throw new Error("Could not read page content. Reload the page and retry."); });
  if (!Array.isArray(slices) || slices.length === 0) throw new Error("Page returned no slices.");
  const images = await Promise.all(slices.map((s) => loadImage(s.url)));
  const totalH = slices.reduce((a, s) => a + s.height, 0);
  const width = images[0]?.naturalWidth ?? 1280;
  const scale = width / ((await pageWidth(tabId)) || width);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = Math.min(16384, Math.round(totalH * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable.");
  let y = 0;
  for (let i = 0; i < images.length; i++) {
    const img = images[i];
    if (!img) continue;
    const h = Math.round((slices[i]?.height ?? 0) * scale);
    if (y + h > canvas.height) break;
    ctx.drawImage(img, 0, y, canvas.width, h);
    y += h;
  }
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/png"));
  if (!blob || blob.size === 0) throw new Error("Stitching failed (empty image).");
  return blob;
}

async function pageWidth(tabId: number): Promise<number> {
  try {
    const r = await chrome.tabs.sendMessage<unknown, { innerWidth: number }>(tabId, { kind: "page-width" });
    return r?.innerWidth ?? 0;
  } catch { return 0; }
}

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

export async function downloadBlob(blob: Blob, filename: string): Promise<void> {
  if (blob.size === 0) throw new Error("Refusing to save an empty file.");
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({ url, filename, saveAs: false, conflictAction: "uniquify" });
  } finally {
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
}
