import { isRestrictedUrl, logError } from "../shared/errors.ts";
import { activeTab, captureVisible } from "../shared/capture.ts";
import { loadSettings } from "../shared/storage.ts";

const $ = (id: string) => document.getElementById(id) as HTMLElement;
const status = $("status") as HTMLParagraphElement;

function say(m: string): void { status.textContent = m; }

async function init(): Promise<void> {
  const s = await loadSettings();
  ($("delay") as HTMLSelectElement).value = String(Math.min(10, s.countdownSeconds));
  ($("mic") as HTMLInputElement).checked = s.micDefault;
  ($("sys") as HTMLInputElement).checked = s.systemAudioDefault;
  ($("res") as HTMLSelectElement).value = s.recorderResolution;
  document.querySelectorAll("nav button").forEach((b) => b.addEventListener("click", () => {
    document.querySelectorAll("nav button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    const rec = b.getAttribute("data-tab") === "rec";
    ($("shotPane") as HTMLElement).hidden = rec;
    ($("recPane") as HTMLElement).hidden = !rec;
  }));
  ($("themeBtn") as HTMLButtonElement).onclick = () => {
    document.documentElement.dataset.theme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  };
  ($("visBtn") as HTMLButtonElement).onclick = () => void doCapture("visible");
  ($("fullBtn") as HTMLButtonElement).onclick = () => void doCapture("full");
  ($("screenBtn") as HTMLButtonElement).onclick = () => void doCapture("screen");
  ($("areaBtn") as HTMLButtonElement).onclick = async () => {
    const tab = await activeTab().catch((e: unknown) => { say("No active tab."); logError("area", e); return null; });
    if (!tab?.id) return;
    if (isRestrictedUrl(tab.url)) { say("This page blocks capture. Try a normal page."); return; }
    say("Starting selection…");
    if (await sendAreaSelect(tab.id)) window.close();
  };
  ($("editorBtn") as HTMLButtonElement).onclick = async () => {
    await chrome.tabs.create({ url: chrome.runtime.getURL("src/editor/index.html") });
  };
  ($("startBtn") as HTMLButtonElement).onclick = () => void startRec();
  ($("stopBtn") as HTMLButtonElement).onclick = () => void chrome.runtime.sendMessage({ kind: "stop-recording" });
}

async function captureDesktopFrame(): Promise<string> {
  const streamId: string | undefined = await new Promise((resolve) => {
    chrome.desktopCapture.chooseDesktopMedia(["screen", "window"], (id) => resolve(id || undefined));
  });
  if (!streamId) throw new Error("Screen pick cancelled.");
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { mandatory: { chromeMediaSource: "desktop", chromeMediaSourceId: streamId } } as MediaTrackConstraints,
  });
  try {
    const track = stream.getVideoTracks()[0];
    if (!track) throw new Error("No video track.");
    const cap = new ImageCapture(track);
    const grabber = cap as unknown as { grabFrame(): Promise<ImageBitmap> };
    const bmp = await grabber.grabFrame();
    const canvas = document.createElement("canvas");
    canvas.width = bmp.width; canvas.height = bmp.height;
    canvas.getContext("2d")?.drawImage(bmp, 0, 0);
    bmp.close();
    const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, "image/png"));
    if (!blob || blob.size === 0) throw new Error("Frame grab failed.");
    return await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result));
      fr.onerror = () => reject(new Error("Frame encode failed."));
      fr.readAsDataURL(blob);
    });
  } finally {
    for (const t of stream.getTracks()) { try { t.stop(); } catch { /* noop */ } }
  }
}

async function sendAreaSelect(tabId: number): Promise<boolean> {
  try {
    await chrome.tabs.sendMessage(tabId, { kind: "area-select" });
    return true;
  } catch { /* content script not injected yet — fall through to programmatic injection */ }
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await new Promise((r) => setTimeout(r, 200));
    await chrome.tabs.sendMessage(tabId, { kind: "area-select" });
    return true;
  } catch (e) {
    say("Could not start selection here. Reload the page and retry.");
    logError("area-inject", e);
    return false;
  }
}

async function countdown(sec: number): Promise<void> {
  for (let i = sec; i > 0; i--) { say(`Capturing in ${i}…`); await new Promise((r) => setTimeout(r, 1000)); }
}

async function doCapture(mode: "visible" | "full" | "screen"): Promise<void> {
  try {
    const sec = Number(($("delay") as HTMLSelectElement).value) || 0;
    if (sec > 0) await countdown(sec);
    if (mode === "visible") {
      const url = await captureVisible();
      await chrome.storage.local.set({ "snapora.lastShot": { url, area: null, at: Date.now() } });
      await chrome.tabs.create({ url: chrome.runtime.getURL("src/editor/index.html") });
      window.close();
    } else if (mode === "screen") {
      say("Pick a screen or window…");
      const url = await captureDesktopFrame();
      await chrome.storage.local.set({ "snapora.lastShot": { url, area: null, at: Date.now() } });
      await chrome.tabs.create({ url: chrome.runtime.getURL("src/editor/index.html") });
      window.close();
    } else {
      const tab = await activeTab();
      if (!tab.id || isRestrictedUrl(tab.url)) { say("This page blocks capture."); return; }
      say("Full-page capture started — see editor.");
      await chrome.tabs.create({ url: chrome.runtime.getURL("src/editor/index.html?fullpage=" + tab.id) });
      window.close();
    }
  } catch (e) {
    say(e instanceof Error ? e.message : "Capture failed.");
    logError("popup-capture", e);
  }
}

async function startRec(): Promise<void> {
  try {
    const streamId: string | undefined = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(["screen", "window", "tab"], (id) => resolve(id || undefined));
    });
    if (!streamId) { say("Recording cancelled — no source picked."); return; }
    ($("stopBtn") as HTMLButtonElement).disabled = false;
    ($("startBtn") as HTMLButtonElement).disabled = true;
    ($("recNote") as HTMLElement).textContent = "Recording… use Stop (Alt+Shift+S).";
    await chrome.runtime.sendMessage({
      kind: "start-recording",
      payload: {
        source: ($("src") as HTMLSelectElement).value,
        resolution: ($("res") as HTMLSelectElement).value,
        micOn: ($("mic") as HTMLInputElement).checked,
        systemAudio: ($("sys") as HTMLInputElement).checked,
        streamId,
      },
    });
  } catch (e) { say("Recording failed to start."); logError("popup-rec", e); }
}

void init();
