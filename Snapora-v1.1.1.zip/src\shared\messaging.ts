import { logError } from "./errors.ts";
import type { ExtensionMessage } from "./types.ts";

export function sendMessage(msg: ExtensionMessage): Promise<unknown> {
  return chrome.runtime.sendMessage(msg).catch((e: unknown) => {
    logError("sendMessage", e);
    return null;
  });
}

export function onMessage(handler: (msg: ExtensionMessage) => void | Promise<void>): void {
  chrome.runtime.onMessage.addListener((raw: unknown) => {
    const msg = raw as ExtensionMessage;
    if (!msg || typeof msg.kind !== "string") return false;
    void Promise.resolve(handler(msg));
    return false;
  });
}
