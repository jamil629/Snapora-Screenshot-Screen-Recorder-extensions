import { buildFileName } from "../shared/compat.ts";
import { logError } from "../shared/errors.ts";
import { RecorderEngine, type RecorderOptions } from "../shared/recorder.ts";
import { saveRecording } from "../shared/blob-store.ts";
import type { ExtensionMessage } from "../shared/types.ts";

const engine = new RecorderEngine();
let startFailed = false;

chrome.runtime.onMessage.addListener((raw: unknown) => {
  const msg = raw as ExtensionMessage;
  if (msg.kind === "start-recording") {
    startFailed = false;
    const p = (msg.payload ?? {}) as Record<string, unknown>;
    const opts: RecorderOptions = {
      source: (p.source as RecorderOptions["source"]) ?? "tab",
      resolution: (p.resolution as RecorderOptions["resolution"]) ?? "1080p",
      micOn: p.micOn === true,
      systemAudio: p.systemAudio !== false,
      webcamOn: p.webcamOn === true,
    };
    void engine.start(opts, typeof p.streamId === "string" ? p.streamId : undefined).catch((e: unknown) => {
      startFailed = true;
      logError("rec-start", e);
      void chrome.storage.local.set({ "snapora.recError": { message: e instanceof Error ? e.message : String(e), at: Date.now() } }).catch(() => undefined);
    });
  } else if (msg.kind === "stop-recording") {
    void engine.stop().then(async (blob) => {
      const name = buildFileName("recording", "webm");
      await saveRecording(blob).catch((e: unknown) => logError("rec-store", e));
      const url = URL.createObjectURL(blob);
      try {
        await chrome.downloads.download({ url, filename: name, saveAs: false, conflictAction: "uniquify" });
        await chrome.storage.local.set({ "snapora.lastRecording": { name, size: blob.size, type: blob.type, at: Date.now() } }).catch(() => undefined);
      } catch (e) {
        logError("rec-download", e);
        await chrome.storage.local.set({ "snapora.recError": { message: "Download failed — recording kept nowhere. Retry with free disk space.", at: Date.now() } }).catch(() => undefined);
      } finally {
        window.setTimeout(() => URL.revokeObjectURL(url), 120_000);
      }
      await chrome.runtime.sendMessage({ kind: "open-video-editor" }).catch(() => undefined);
    }).catch((e: unknown) => {
      logError("rec-stop", e);
      void chrome.storage.local.set({ "snapora.recError": { message: startFailed ? "Recording never started (permission denied or no source)." : "Stop failed.", at: Date.now() } }).catch(() => undefined);
    });
  } else if (msg.kind === "pause-recording") engine.pause();
  else if (msg.kind === "resume-recording") engine.resume();
});
