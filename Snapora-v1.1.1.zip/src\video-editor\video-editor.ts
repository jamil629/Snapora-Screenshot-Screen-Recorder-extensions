import { buildFileName } from "../shared/compat.ts";
import { downloadBlob } from "../shared/capture.ts";
import { logError } from "../shared/errors.ts";
import { loadRecording } from "../shared/blob-store.ts";
import { convertWebmToMp4, type Mp4Handle } from "../shared/mp4.ts";

const v = document.getElementById("v") as HTMLVideoElement;
const info = document.getElementById("info") as HTMLElement;
const prog = document.getElementById("prog") as HTMLElement;
const bar = document.getElementById("bar2") as HTMLProgressElement;
const mp4Btn = document.getElementById("mp4") as HTMLButtonElement;
const cancelBtn = document.getElementById("cancelMp4") as HTMLButtonElement;

let objectUrl: string | null = null;
let webm: Blob | null = null;
let active: Mp4Handle | null = null;

async function boot(): Promise<void> {
  try {
    const got = await chrome.storage.local.get("snapora.recError").catch(() => ({}));
    const err = (got as Record<string, unknown>)["snapora.recError"] as { message: string } | undefined;
    webm = await loadRecording().catch(() => null);
    if (err && !webm) { info.textContent = "Recorder reported: " + err.message; return; }
    if (!webm || webm.size === 0) {
      info.textContent = "No recording yet. Record something — it appears here for preview and MP4 export.";
      mp4Btn.disabled = true;
      return;
    }
    objectUrl = URL.createObjectURL(webm);
    v.src = objectUrl;
    info.textContent = `Preview: ${(webm.size / 1048576).toFixed(2)} MB WebM. Export MP4 when ready — the file stays local.`;
  } catch (e) {
    info.textContent = "Could not load the recording.";
    logError("vedit-boot", e);
  }
}

mp4Btn.onclick = async () => {
  if (!webm) return;
  mp4Btn.disabled = true;
  cancelBtn.disabled = false;
  bar.hidden = false;
  bar.value = 0;
  prog.textContent = "Loading converter (first time only)…";
  try {
    active = convertWebmToMp4(webm, (p) => {
      if (p.fraction >= 0) {
        bar.value = Math.round(p.fraction * 100);
        prog.textContent = `Converting… ${Math.round(p.fraction * 100)}%`;
      } else {
        prog.textContent = `Converting… ${(p.bytes / 1048576).toFixed(1)} MB written`;
      }
    });
    const mp4 = await active.promise;
    const name = buildFileName("recording", "mp4");
    await downloadBlob(mp4, name);
    prog.textContent = `Saved ${name} (${(mp4.size / 1048576).toFixed(2)} MB).`;
  } catch (e) {
    prog.textContent = e instanceof Error ? e.message : "MP4 export failed. Your WebM is untouched.";
    logError("mp4", e);
  } finally {
    active = null;
    mp4Btn.disabled = false;
    cancelBtn.disabled = true;
    bar.hidden = true;
  }
};

cancelBtn.onclick = async () => {
  if (active) {
    await active.cancel().catch(() => undefined);
    prog.textContent = "Cancelling…";
  }
};

(document.getElementById("mute") as HTMLButtonElement).onclick = () => { v.muted = !v.muted; prog.textContent = v.muted ? "Muted." : "Unmuted."; };

(document.getElementById("snap") as HTMLButtonElement).onclick = async () => {
  try {
    if (!v.videoWidth) throw new Error("No video loaded.");
    const c = document.createElement("canvas");
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext("2d")?.drawImage(v, 0, 0);
    const blob = await new Promise<Blob | null>((r) => c.toBlob(r, "image/png"));
    if (!blob || blob.size === 0) throw new Error("Empty frame.");
    await downloadBlob(blob, buildFileName("screenshot", "png"));
    prog.textContent = "Frame saved.";
  } catch (e) { prog.textContent = "Snapshot failed."; logError("snap", e); }
};

(document.getElementById("dl") as HTMLButtonElement).onclick = async () => {
  try {
    if (!webm) { prog.textContent = "No recording loaded."; return; }
    await downloadBlob(webm, buildFileName("recording", "webm"));
    prog.textContent = "WebM saved.";
  } catch (e) { prog.textContent = "Download failed."; logError("dl", e); }
};

window.addEventListener("beforeunload", () => { if (objectUrl) URL.revokeObjectURL(objectUrl); });
void boot();
