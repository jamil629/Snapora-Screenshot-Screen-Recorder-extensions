export type ScreenshotFormat = "png" | "jpg" | "pdf";
export type Theme = "dark" | "light" | "system";
export type RecorderSource = "tab" | "screen" | "window" | "camera";
export type RecorderResolution = "720p" | "1080p" | "4k";
export type MessageKind =
  | "capture-visible" | "capture-fullpage" | "capture-area" | "capture-screen"
  | "start-recording" | "stop-recording" | "pause-recording" | "resume-recording"
  | "recording-state" | "open-editor" | "open-video-editor" | "settings-changed" | "error-report"
  | "capture-visible-slice";

export interface SnaporaSettings {
  screenshotFormat: ScreenshotFormat;
  jpegQuality: number;
  recorderResolution: RecorderResolution;
  countdownSeconds: number;
  micDefault: boolean;
  systemAudioDefault: boolean;
  webcamDefault: boolean;
  cameraPosition: "br" | "bl" | "tr" | "tl";
  cameraSize: number;
  saveFolder: string;
  theme: Theme;
  privacyStrict: boolean;
}

export const DEFAULT_SETTINGS: SnaporaSettings = {
  screenshotFormat: "png",
  jpegQuality: 0.92,
  recorderResolution: "1080p",
  countdownSeconds: 3,
  micDefault: false,
  systemAudioDefault: true,
  webcamDefault: false,
  cameraPosition: "br",
  cameraSize: 160,
  saveFolder: "",
  theme: "system",
  privacyStrict: true,
};

export interface ExtensionMessage {
  kind: MessageKind;
  payload?: Record<string, unknown>;
}

export interface RecordingState {
  active: boolean;
  paused: boolean;
  startedAt: number;
  source: RecorderSource | null;
}
